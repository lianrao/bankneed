prompt PL/SQL Developer import file
prompt Created on 2009��3��12�� by ferrari
set feedback off
set define off
prompt Disabling triggers for DD_CASTE...
alter table DD_CASTE disable all triggers;
prompt Disabling triggers for DD_CERTIFICATE...
alter table DD_CERTIFICATE disable all triggers;
prompt Disabling triggers for DD_CHECKRESULT...
alter table DD_CHECKRESULT disable all triggers;
prompt Disabling triggers for DD_DUTY...
alter table DD_DUTY disable all triggers;
prompt Disabling triggers for DD_EDUDEGREE...
alter table DD_EDUDEGREE disable all triggers;
prompt Disabling triggers for DD_EDULEVEL...
alter table DD_EDULEVEL disable all triggers;
prompt Disabling triggers for DD_FINANCEORG...
alter table DD_FINANCEORG disable all triggers;
prompt Disabling triggers for DD_GENDER...
alter table DD_GENDER disable all triggers;
prompt Disabling triggers for DD_INDUSTRY...
alter table DD_INDUSTRY disable all triggers;
prompt Disabling triggers for DD_LOC...
alter table DD_LOC disable all triggers;
prompt Disabling triggers for DD_MARRIAGE...
alter table DD_MARRIAGE disable all triggers;
prompt Disabling triggers for DD_NATRUE...
alter table DD_NATRUE disable all triggers;
prompt Disabling triggers for DD_OCCUPATION...
alter table DD_OCCUPATION disable all triggers;
prompt Disabling triggers for DD_OPT_TYPE...
alter table DD_OPT_TYPE disable all triggers;
prompt Disabling triggers for DD_PERATION_OPT...
alter table DD_PERATION_OPT disable all triggers;
prompt Disabling triggers for DD_PERATION_STATUS...
alter table DD_PERATION_STATUS disable all triggers;
prompt Disabling triggers for DD_PERATION_TYPE...
alter table DD_PERATION_TYPE disable all triggers;
prompt Disabling triggers for DD_RESIDENCE...
alter table DD_RESIDENCE disable all triggers;
prompt Disabling triggers for DD_SHOW...
alter table DD_SHOW disable all triggers;
prompt Disabling triggers for DD_STATUS...
alter table DD_STATUS disable all triggers;
prompt Disabling triggers for DD_TEL...
alter table DD_TEL disable all triggers;
prompt Deleting DD_TEL...
delete from DD_TEL;
commit;
prompt Deleting DD_STATUS...
delete from DD_STATUS;
commit;
prompt Deleting DD_SHOW...
delete from DD_SHOW;
commit;
prompt Deleting DD_RESIDENCE...
delete from DD_RESIDENCE;
commit;
prompt Deleting DD_PERATION_TYPE...
delete from DD_PERATION_TYPE;
commit;
prompt Deleting DD_PERATION_STATUS...
delete from DD_PERATION_STATUS;
commit;
prompt Deleting DD_PERATION_OPT...
delete from DD_PERATION_OPT;
commit;
prompt Deleting DD_OPT_TYPE...
delete from DD_OPT_TYPE;
commit;
prompt Deleting DD_OCCUPATION...
delete from DD_OCCUPATION;
commit;
prompt Deleting DD_NATRUE...
delete from DD_NATRUE;
commit;
prompt Deleting DD_MARRIAGE...
delete from DD_MARRIAGE;
commit;
prompt Deleting DD_LOC...
delete from DD_LOC;
commit;
prompt Deleting DD_INDUSTRY...
delete from DD_INDUSTRY;
commit;
prompt Deleting DD_GENDER...
delete from DD_GENDER;
commit;
prompt Deleting DD_FINANCEORG...
delete from DD_FINANCEORG;
commit;
prompt Deleting DD_EDULEVEL...
delete from DD_EDULEVEL;
commit;
prompt Deleting DD_EDUDEGREE...
delete from DD_EDUDEGREE;
commit;
prompt Deleting DD_DUTY...
delete from DD_DUTY;
commit;
prompt Deleting DD_CHECKRESULT...
delete from DD_CHECKRESULT;
commit;
prompt Deleting DD_CERTIFICATE...
delete from DD_CERTIFICATE;
commit;
prompt Deleting DD_CASTE...
delete from DD_CASTE;
commit;
prompt Loading DD_CASTE...
insert into DD_CASTE (CASTECODE, CASTENAME, STOPFLAG)
values (1, '�߼�', 0);
insert into DD_CASTE (CASTECODE, CASTENAME, STOPFLAG)
values (2, '�м�', 0);
insert into DD_CASTE (CASTECODE, CASTENAME, STOPFLAG)
values (3, '����', 0);
insert into DD_CASTE (CASTECODE, CASTENAME, STOPFLAG)
values (4, '��', 0);
commit;
prompt 4 records loaded
prompt Loading DD_CERTIFICATE...
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('6', '̨��ͬ�������ڵ�ͨ��֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('5', '�۰ľ��������ڵ�ͨ��֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('4', 'ʿ��֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('3', '����֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('2', '����', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('1', '���ڲ�', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('0', '����֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('7', '��ʱ����֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('8', '����˾���֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('9', '����֤', 0);
insert into DD_CERTIFICATE (CERTCODE, CERTNAME, STOPFLAG)
values ('x', '����֤��', 0);
commit;
prompt 11 records loaded
prompt Loading DD_CHECKRESULT...
insert into DD_CHECKRESULT (RESULTLCODE, RESULTNAME, STOPFLAG)
values ('1', '��ô���', 0);
insert into DD_CHECKRESULT (RESULTLCODE, RESULTNAME, STOPFLAG)
values ('0', 'δ��ѯ', 0);
insert into DD_CHECKRESULT (RESULTLCODE, RESULTNAME, STOPFLAG)
values ('2', '���޴���', 0);
commit;
prompt 3 records loaded
prompt Loading DD_DUTY...
insert into DD_DUTY (DUTYCODE, DUTYNAME, STOPFLAG)
values (1, '�߼��쵼����������ּ����ּ������쵼���˾�߼�������Ա��', 0);
insert into DD_DUTY (DUTYCODE, DUTYNAME, STOPFLAG)
values (2, '�м��쵼����������ּ������쵼���˾�м�������Ա��', 0);
insert into DD_DUTY (DUTYCODE, DUTYNAME, STOPFLAG)
values (3, 'һ��Ա��', 0);
insert into DD_DUTY (DUTYCODE, DUTYNAME, STOPFLAG)
values (4, '����', 0);
commit;
prompt 4 records loaded
prompt Loading DD_EDUDEGREE...
insert into DD_EDUDEGREE (DEGREECODE, DEGREENAME, STOPFLAG)
values (1, '������ʿ', 0);
insert into DD_EDUDEGREE (DEGREECODE, DEGREENAME, STOPFLAG)
values (2, '��ʿ', 0);
insert into DD_EDUDEGREE (DEGREECODE, DEGREENAME, STOPFLAG)
values (3, '˶ʿ', 0);
insert into DD_EDUDEGREE (DEGREECODE, DEGREENAME, STOPFLAG)
values (4, 'ѧʿ', 0);
insert into DD_EDUDEGREE (DEGREECODE, DEGREENAME, STOPFLAG)
values (5, '����', 0);
commit;
prompt 5 records loaded
prompt Loading DD_EDULEVEL...
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (1, '�о���', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (2, '��ѧ���ƣ����"��ѧ"��', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (3, '��ѧר�ƺ�ר��ѧУ�����"��ר"��', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (4, '�е�רҵѧУ���еȼ���ѧУ', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (5, '����ѧУ', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (6, '����', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (7, '����', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (8, 'Сѧ', 0);
insert into DD_EDULEVEL (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values (9, '��ä�����ä', 0);
commit;
prompt 9 records loaded
prompt Loading DD_FINANCEORG...
insert into DD_FINANCEORG (FINANCECODE, FINANCENAME, CORPORATENAME, STOPFLAG)
values ('person00000000', '�û�', null, null);
insert into DD_FINANCEORG (FINANCECODE, FINANCENAME, CORPORATENAME, STOPFLAG)
values ('certificate000', '����֤', null, null);
commit;
prompt 2 records loaded
prompt Loading DD_GENDER...
insert into DD_GENDER (GENDERCODE, GENDERNAME, STOPFLAG)
values (1, '����', 0);
insert into DD_GENDER (GENDERCODE, GENDERNAME, STOPFLAG)
values (2, 'Ů��', 0);
commit;
prompt 2 records loaded
prompt Loading DD_INDUSTRY...
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('a', 'ũ���֡�������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('b', '�ɾ�ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('c', '����ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('d', '������ȼ����ˮ�������͹�Ӧҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('e', '����ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('f', '��ͨ���䡢�ִ�������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('g', '��Ϣ���䡢��������������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('h', '����������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('i', 'ס�޺Ͳ���ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('j', '����ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('k', '���ز�ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('l', '���޺��������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('m', '��ѧ�о�����������ҵ�͵��ʿ���ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('n', 'ˮ���������͹�����ʩ����ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('o', '����������������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('p', '����', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('q', '��������ᱣ�Ϻ���ḣ��ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('r', '�Ļ�������������ҵ', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('s', '���������������', 0);
insert into DD_INDUSTRY (INDUSTRYCODE, INDUSTRYNAME, STOPFLAG)
values ('t', '������֯', 0);
commit;
prompt 20 records loaded
prompt Loading DD_LOC...
insert into DD_LOC (LOCTYPECODE, LOCTYPENAME, STOPFLAG)
values ('3', '��λ��ַ', 0);
insert into DD_LOC (LOCTYPECODE, LOCTYPENAME, STOPFLAG)
values ('2', 'סլ��ַ', 0);
insert into DD_LOC (LOCTYPECODE, LOCTYPENAME, STOPFLAG)
values ('1', '-ͨ�ŵ�ַ', 0);
insert into DD_LOC (LOCTYPECODE, LOCTYPENAME, STOPFLAG)
values ('4', '������ַ', 0);
commit;
prompt 4 records loaded
prompt Loading DD_MARRIAGE...
insert into DD_MARRIAGE (MARRIAGECODE, MARRIAGENAME, STOPFLAG)
values (1, 'δ��', 0);
insert into DD_MARRIAGE (MARRIAGECODE, MARRIAGENAME, STOPFLAG)
values (2, '�ѻ�', 0);
insert into DD_MARRIAGE (MARRIAGECODE, MARRIAGENAME, STOPFLAG)
values (3, 'ɥż', 0);
insert into DD_MARRIAGE (MARRIAGECODE, MARRIAGENAME, STOPFLAG)
values (4, '���', 0);
commit;
prompt 4 records loaded
prompt Loading DD_NATRUE...
insert into DD_NATRUE (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values ('1', '��ҵ��λ', 0);
insert into DD_NATRUE (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values ('2', '��������', 0);
insert into DD_NATRUE (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values ('3', '����', 0);
insert into DD_NATRUE (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values ('4', '�������', 0);
insert into DD_NATRUE (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values ('5', '��ҵ', 0);
insert into DD_NATRUE (EDULEVELCODE, EDULEVELNAME, STOPFLAG)
values ('6', '���徭Ӫ', 0);
commit;
prompt 6 records loaded
prompt Loading DD_OCCUPATION...
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('1', '���һ��ء���Ⱥ��֯����ҵ����ҵ��λ������', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('2', 'רҵ������', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('3', '������Ա���й���Ա', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('4', '��ҵ������ҵ��Ա', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('5', 'ũ���֡������桢ˮ��ҵ������Ա', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('6', '�����������豸������Ա���й���Ա', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('7', '����', 0);
insert into DD_OCCUPATION (OCCUPATIONCODE, OCCUPATIONNAME, STOPFLAG)
values ('8', '��������������ҵ��Ա', 0);
commit;
prompt 8 records loaded
prompt Loading DD_OPT_TYPE...
insert into DD_OPT_TYPE (OTYPECODE, OTYPENAME, STOPFLAG)
values ('2', '�ӹ�', 0);
insert into DD_OPT_TYPE (OTYPECODE, OTYPENAME, STOPFLAG)
values ('1', '��ȡ', 0);
insert into DD_OPT_TYPE (OTYPECODE, OTYPENAME, STOPFLAG)
values ('3', '��Ǩ', 0);
commit;
prompt 3 records loaded
prompt Loading DD_PERATION_OPT...
insert into DD_PERATION_OPT (PTYPECODE, PTYPENAME, STOPFLAG)
values ('1', '����', 0);
insert into DD_PERATION_OPT (PTYPECODE, PTYPENAME, STOPFLAG)
values ('0', 'ɾ��', 0);
insert into DD_PERATION_OPT (PTYPECODE, PTYPENAME, STOPFLAG)
values ('2', '����', 0);
commit;
prompt 3 records loaded
prompt Loading DD_PERATION_STATUS...
insert into DD_PERATION_STATUS (PSTATUSCODE, PSTATUSNAME, STOPFLAG)
values ('4', '����������', 0);
insert into DD_PERATION_STATUS (PSTATUSCODE, PSTATUSNAME, STOPFLAG)
values ('3', '������������', 0);
insert into DD_PERATION_STATUS (PSTATUSCODE, PSTATUSNAME, STOPFLAG)
values ('2', '�Ѵ���', 0);
insert into DD_PERATION_STATUS (PSTATUSCODE, PSTATUSNAME, STOPFLAG)
values ('1', '���ڴ���', 0);
insert into DD_PERATION_STATUS (PSTATUSCODE, PSTATUSNAME, STOPFLAG)
values ('0', 'δ����', 0);
commit;
prompt 5 records loaded
prompt Loading DD_PERATION_TYPE...
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('25', '��ҵ��Ϣ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('24', '������Ϣ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('23', '������Ϣ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('22', '��ַ��Ϣ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('21', '�绰��Ϣ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('7', '������ַ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('6', '��������', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('5', '�μӹ�������', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('4', '���ѧλ', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('3', '���ѧ��', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('2', '��������', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('1', '�Ա�', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('0', '�����˲���', 0);
insert into DD_PERATION_TYPE (PTYPECODE, PTYPENAME, STOPFLAG)
values ('26', '��������Ϣ', 0);
commit;
prompt 14 records loaded
prompt Loading DD_RESIDENCE...
insert into DD_RESIDENCE (RESCODE, RESNAME, STOPFLAG)
values ('1', '����', 0);
insert into DD_RESIDENCE (RESCODE, RESNAME, STOPFLAG)
values ('2', '����', 0);
commit;
prompt 2 records loaded
prompt Loading DD_SHOW...
insert into DD_SHOW (STYPECODE, STYPENAME, STOPFLAG)
values ('0', '��ʷ', 0);
insert into DD_SHOW (STYPECODE, STYPENAME, STOPFLAG)
values ('1', '�Ƽ�', 0);
commit;
prompt 2 records loaded
prompt Loading DD_STATUS...
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('42', '���ڸ��¡��ӹ����', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('38', '���ڸ��¡����ڼӹ�', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('37', '���ڳ�ȡ��ӹ������ڸ���', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('34', '���ڸ��¡���ȡ���', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('33', '���ڸ��¡����ڳ�ȡ', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('32', '���ڸ���', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('26', '���ڻ�Ǩ', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('10', '�ӹ����', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('6', '���ڼӹ�', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('5', '���ڳ�ȡ��ӹ�', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('2', '��ȡ���', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('1', '���ڳ�ȡ', 0);
insert into DD_STATUS (STATUSCODE, STATUSNAME, STOPFLAG)
values ('0', '����', 0);
commit;
prompt 13 records loaded
prompt Loading DD_TEL...
insert into DD_TEL (TELTYPECODE, TELTYPENAME, STOPFLAG)
values ('3', '�ֻ�����', 0);
insert into DD_TEL (TELTYPECODE, TELTYPENAME, STOPFLAG)
values ('2', '��λ�绰', 0);
insert into DD_TEL (TELTYPECODE, TELTYPENAME, STOPFLAG)
values ('1', 'סլ�绰', 0);
insert into DD_TEL (TELTYPECODE, TELTYPENAME, STOPFLAG)
values ('4', '�����绰', 0);
commit;
prompt 4 records loaded
prompt Enabling triggers for DD_CASTE...
alter table DD_CASTE enable all triggers;
prompt Enabling triggers for DD_CERTIFICATE...
alter table DD_CERTIFICATE enable all triggers;
prompt Enabling triggers for DD_CHECKRESULT...
alter table DD_CHECKRESULT enable all triggers;
prompt Enabling triggers for DD_DUTY...
alter table DD_DUTY enable all triggers;
prompt Enabling triggers for DD_EDUDEGREE...
alter table DD_EDUDEGREE enable all triggers;
prompt Enabling triggers for DD_EDULEVEL...
alter table DD_EDULEVEL enable all triggers;
prompt Enabling triggers for DD_FINANCEORG...
alter table DD_FINANCEORG enable all triggers;
prompt Enabling triggers for DD_GENDER...
alter table DD_GENDER enable all triggers;
prompt Enabling triggers for DD_INDUSTRY...
alter table DD_INDUSTRY enable all triggers;
prompt Enabling triggers for DD_LOC...
alter table DD_LOC enable all triggers;
prompt Enabling triggers for DD_MARRIAGE...
alter table DD_MARRIAGE enable all triggers;
prompt Enabling triggers for DD_NATRUE...
alter table DD_NATRUE enable all triggers;
prompt Enabling triggers for DD_OCCUPATION...
alter table DD_OCCUPATION enable all triggers;
prompt Enabling triggers for DD_OPT_TYPE...
alter table DD_OPT_TYPE enable all triggers;
prompt Enabling triggers for DD_PERATION_OPT...
alter table DD_PERATION_OPT enable all triggers;
prompt Enabling triggers for DD_PERATION_STATUS...
alter table DD_PERATION_STATUS enable all triggers;
prompt Enabling triggers for DD_PERATION_TYPE...
alter table DD_PERATION_TYPE enable all triggers;
prompt Enabling triggers for DD_RESIDENCE...
alter table DD_RESIDENCE enable all triggers;
prompt Enabling triggers for DD_SHOW...
alter table DD_SHOW enable all triggers;
prompt Enabling triggers for DD_STATUS...
alter table DD_STATUS enable all triggers;
prompt Enabling triggers for DD_TEL...
alter table DD_TEL enable all triggers;
set feedback on
set define on
prompt Done.
